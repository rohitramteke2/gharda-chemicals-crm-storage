# RDP Server Debug Guide — Zoho CRM API

## What went wrong (from your actual logs)

Your `code.zip` contained real error logs from the RDP. Here's exactly what happened on March 11:

### 5 root causes found

| # | Issue | Evidence |
|---|-------|----------|
| 1 | **`.env` has placeholder credentials** | Your `.env` file contains literal text `<get from Gharda's Zoho API Console>` instead of real values |
| 2 | **`NODE_ENV=development` on RDP** | Logs show `"env":"development"` — this means the SSL-bypass `httpsAgent` is never created |
| 3 | **`dotenv/config` only loads `.env`** | Your `.env.production` has real credentials but `import 'dotenv/config'` ignores it completely |
| 4 | **`redirect_uri` mismatch** | 3 different values across configs — Zoho requires an exact match with the API Console |
| 5 | **Public vs private Zoho URL confusion** | Postman uses `accounts.zoho.in` (cloud), but `.env.production` uses `zoho.gharda.com:14443` (private) |

**Key insight:** SSL is NOT blocking connections. Your logs prove the RDP server CAN reach Zoho — you got HTTP responses like `invalid_client`, `400`, `401`. The issue is authentication/configuration, not transport.

---

## Step-by-step fix

### Step 1: Determine which Zoho instance you're using

You have two completely different Zoho setups in your configs:

| | Standard Cloud | Private Instance |
|---|---|---|
| **Token URL** | `https://accounts.zoho.in/oauth/v2/token` | `https://zoho.gharda.com:14443/oauth/v2/token` |
| **API Domain** | `https://www.zohoapis.in` | `https://zoho.gharda.com:14443` |
| **SSL** | Valid public cert | Likely self-signed |
| **Credentials** | From `api-console.zoho.in` | From the private instance's admin |

**Your Postman environment uses the Standard Cloud URLs**, and that's what worked on your local machine. Use the same URLs on the RDP unless there's a specific reason to use the private instance.

### Step 2: Deploy the fixed code

1. Copy `sandbox-api-fixed.zip` to the RDP
2. Extract it to `F:\FRISTINE\PROJECT-GHARDA-CHEMICALS\zoho-crm-rdp-api\`
3. Run `npm install`

### Step 3: Configure `.env.production`

Edit `.env.production` on the RDP:

```env
NODE_ENV=production
ZOHO_CLIENT_ID=1000.WSUYSR369YWS2W139AVJFSI7A7BR9N
ZOHO_CLIENT_SECRET=79b7221e18997e74123603c5bec28d35ddef30f70d
ZOHO_REFRESH_TOKEN=<PASTE YOUR FRESH REFRESH TOKEN>
ZOHO_REDIRECT_URI=https://www.gharda.com/
ZOHO_ACCOUNTS_URL=https://accounts.zoho.in/oauth/v2/token
ZOHO_API_DOMAIN=https://www.zohoapis.in
ZOHO_SKIP_SSL_VERIFY=false
```

**Critical:** The `ZOHO_REDIRECT_URI` must match EXACTLY what's in your Zoho API Console.

### Step 4: Generate a fresh refresh token

Refresh tokens expire. Generate a new one:

1. Go to `https://api-console.zoho.in/`
2. Select your Server-Based Application
3. Go to "Generate Code" tab
4. Scope: `ZohoCRM.modules.ALL,ZohoCRM.settings.ALL,ZohoCRM.users.ALL`
5. Copy the grant code
6. Exchange it for a refresh token:

```bash
curl -X POST "https://accounts.zoho.in/oauth/v2/token" \
  -d "grant_type=authorization_code" \
  -d "client_id=1000.WSUYSR369YWS2W139AVJFSI7A7BR9N" \
  -d "client_secret=79b7221e18997e74123603c5bec28d35ddef30f70d" \
  -d "redirect_uri=https://www.gharda.com/" \
  -d "code=PASTE_GRANT_CODE_HERE"
```

7. Paste the `refresh_token` from the response into `.env.production`

### Step 5: Start the server

```bash
# Set NODE_ENV so the correct .env file is loaded
set NODE_ENV=production
node server.js
```

The fixed `server.js` automatically loads `.env.production` when `NODE_ENV=production`.

### Step 6: Test with the diagnostic endpoint

Open in browser: `http://localhost:3000/debug/zoho`

This will show you:
- Whether credentials are loaded (or still placeholders)
- Whether the Zoho accounts URL is reachable
- Whether the API domain is reachable
- Whether token refresh succeeds
- The exact error code if anything fails (e.g., `UNABLE_TO_VERIFY_LEAF_SIGNATURE` for SSL issues)

---

## What the fixes do

### Fixed: `server.js` — environment-aware `.env` loading
Before: `import 'dotenv/config'` (always loads `.env`)
After: Loads `.env.production` when `NODE_ENV=production`, falls back gracefully

### Fixed: `env.js` — SSL agent based on domain, not NODE_ENV
Before: `httpsAgent` only created when `NODE_ENV=production`
After: `httpsAgent` created when `ZOHO_SKIP_SSL_VERIFY=true` OR when the Zoho domain is non-standard (not `*.zohoapis.in` / `*.zoho.in`)

### Fixed: `ZohoService.js` — early credential validation + better logging
Before: Placeholder strings like `<get from...>` were sent to Zoho, causing confusing errors
After: Catches placeholders/missing credentials before making API calls, logs the actual Zoho error response

### Added: `/debug/zoho` diagnostic endpoint
Tests connectivity, credential loading, and token refresh in one call. Use it to pinpoint exactly where things break.

---

## If you DO need the private Zoho instance (`zoho.gharda.com:14443`)

Uncomment Option B in `.env.production`:

```env
ZOHO_ACCOUNTS_URL=https://zoho.gharda.com:14443/oauth/v2/token
ZOHO_API_DOMAIN=https://zoho.gharda.com:14443
ZOHO_SKIP_SSL_VERIFY=true
```

**Important:** You'll need DIFFERENT `client_id` and `client_secret` created in the private instance's API Console, not the ones from `api-console.zoho.in`. They are separate OAuth providers.

---

## Common SSL error codes and what they mean

| Error Code | Meaning | Fix |
|---|---|---|
| `UNABLE_TO_VERIFY_LEAF_SIGNATURE` | Self-signed cert | Set `ZOHO_SKIP_SSL_VERIFY=true` |
| `DEPTH_ZERO_SELF_SIGNED_CERT` | Self-signed cert | Set `ZOHO_SKIP_SSL_VERIFY=true` |
| `CERT_HAS_EXPIRED` | Expired SSL cert | Update the cert on the Zoho server |
| `ECONNREFUSED` | Port not open / server down | Check if `zoho.gharda.com:14443` is running |
| `ENOTFOUND` | DNS can't resolve hostname | Check DNS settings on RDP |
| `ETIMEDOUT` | Firewall blocking | Check firewall rules on RDP |
